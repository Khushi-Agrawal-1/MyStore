package com.lcwd.store.config;

public class AppConstants {
	//for Pagination
	public static final String PAGE_NUMBER = "0";
	public static final String PAGE_SIZE = "1";
	public static final String SORT_BY = "title";
	public static final String SORT_DIR = "asc";

}
